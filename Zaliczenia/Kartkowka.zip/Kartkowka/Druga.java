package com.example.zadanie;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Druga extends AppCompatActivity {
    private TextView txtOdebrane;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_druga);

    }



 public void przeslij (View view){
        Intent intent = getIntent();



        String imie = intent.getStringExtra("imie");
        String email = intent.getStringExtra("email");

        TextView textView = findViewById(R.id.txtOdebrane);
        textView.setText(email + "uzytkownika" + imie);

 }
}